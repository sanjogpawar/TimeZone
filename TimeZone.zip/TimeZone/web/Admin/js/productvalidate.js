let filename=document.getElementById("inputGroupFile01");
let changefilename=document.getElementById("custom-label");

filename.addEventListener("change",showfilename);
function showfilename()
{
    let fname=filename.value;
    fname=fname.substring(fname.lastIndexOf("\\")+1);
    // to avoid the backlash(/) we have added +1 above
    changefilename.textContent=fname;
}
function validateForm()
{

    let author=document.getElementById('author').value;
    let price=document.getElementById('price').value;
    let qty=document.getElementById('qty').value;
    let bname=document.getElementById("bname");
    let c=document.getElementById('inputGroupSelect01');
    let cat=c.options[c.selectedIndex].value;
    let filepath=document.getElementById("inputGroupFile01").value;
    let allowedExtension=/(\.jpg|\.jpeg|\.png|\.gif)$/i;


    if(!author.match(/[A-z]+$/))
    {
        document.getElementById('error_author').textContent="*Please Enter Valid Author Name!";
        document.getElementById('author').focus();
        return false;
    }
    else if(!bname.match(/[A-z]+$/))
    {
        document.getElementById('error_name').textContent="*Please Enter Valid Book Name";
        document.getElementById('bname').focus();
        return false;
    }
    else if(!price.match(/^\d+(?:[.,]\d+)*$/))
    {
        document.getElementById('error_price').textContent="*Please Enter Valid Price!";
        document.getElementById('price').focus();
        return false;
    }
    else if(!qty.match(/^[0-9]+$/))
    {
        document.getElementById('error_qty').textContent="*Please Enter Valid Quantity!";
        document.getElementById('qty').focus();
        return false;
    }
    else if(cat===-1)
    {
        document.getElementById('error_select').textContent="*Please Select a Category!";
        return false;
    }
    else if(filepath==="")
    {
        document.getElementById('error_file').textContent="*Please Upload Image!";
        filepath.value="";
        return false;
    }
    //exec -> search for the particular word is there or not
    else if(!allowedExtension.exec(filepath))
    {
        document.getElementById('error_file').textContent="*Please Upload Valid Image!";
        filepath.value="";
        return false;

    }
    else
    {
        return true;
    }
}


