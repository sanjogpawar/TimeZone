function validateForm()
{
    var aname=document.getElementById("aname").value;
    var email=document.getElementById("email").value;
    var cpass=document.getElementById("cpass").value;
    var pass=document.getElementById("pass").value;
    var msg=document.getElementById("errorname");
    if(!aname.match("^[a-zA-z\\s]+$"))
    {
       
        msg.innerHTML="*Invalid Name!";
        return false;
    }
    else if(!email.match("^[A-z0-9]*@[A-z]*.{1}[a-z]{2,3}$"))
    {
       
       document.getElementById("erroremail").innerHTML="*nvalid Email!";
        return false;
    }
    else if(pass!==cpass)
    {
       
        document.getElementById("errorpass").innerHTML="*Password and Confirm Password Does Not Match!";
        return false;
    }
    else if(pass.length<6)
    {
        
        document.getElementById("errorpass").innerHTML="*Password Must be 6 Character Length!";
        return false;
    }
    else 
    {
        return true;
    }
}


