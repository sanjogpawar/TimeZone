
function validatepay()
{

    const email = document.getElementById("email").value;
    const add = document.getElementById("add").value;
    const land = document.getElementById("landmark").value;
    const zip=document.getElementById("zipcode").value;
    const city=document.getElementById("city").value;
    const state=document.getElementById("state").value;
    if(!email.match("^[A-z0-9]*@[A-z]*\\.{1}[a-z]{2,3}$"))
    {
        document.getElementById("error_email").innerHTML="*Invalid Email!";
        document.getElementById("email").focus();
        return false;
    }
    else if(!add.match("^[A-z\\s,]+$"))
    {
        document.getElementById("error_add").innerHTML="*Invalid Address!";
        document.getElementById("add").focus();
        return false;
    }
    else if(!land.match("^[A-z\\s]+$"))
    {
        document.getElementById("error_land").innerHTML="*Invalid LandMark!";
        document.getElementById("landmark").focus();
        return false;
    }
    else if(!zip.match("^[0-9]{6}$"))
    {
        document.getElementById("error_zip").innerHTML="*Invalid ZipCode!";
        document.getElementById("zipcode").focus();
        return false;
    }
    else if(!city.match("^[A-z\\s]+$"))
    {
        document.getElementById("error_city").innerHTML="*Invalid City!";
        document.getElementById("city").focus();
        return false;
    }
    else if(!state.match("^[A-z\\s]+$"))
    {
        document.getElementById("error_state").innerHTML="*Invalid State!";
        document.getElementById("state").focus();
        return false;
    }
    else
    {
        return true;
    }
}

