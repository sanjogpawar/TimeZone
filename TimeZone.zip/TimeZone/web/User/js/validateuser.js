function validateForm()
{
    const fname=document.getElementById("fname").value;
    const lname=document.getElementById("lname").value;
    const uemail=document.getElementById("uemail").value;
    const cpass=document.getElementById("cpass").value;
    const mob=document.getElementById("phone").value;
    const pass=document.getElementById("pass").value;
    if(!fname.match("^[A-z]+$"))
    {
       
        document.getElementById("error_fname").innerHTML="*Invalid First Name!";
        document.getElementById("fname").focus();
        return false;
    }
    else if(!lname.match("^[A-z]+$"))
    {
       
       document.getElementById("error_lname").innerHTML="*Invalid Last Name!";
       document.getElementById("lname").focus();
        return false;
    }
    else if(!uemail.match("^[A-z0-9]*@[A-z]*\\.{1}[a-z]{2,3}$"))
    {
       
       document.getElementById("error_email").innerHTML="*Invalid Email!";
       document.getElementById("uemail").focus();
        return false;
    }
    else if(!mob.match("^[0-9]{10}$"))
    {
       
       document.getElementById("error_mob").innerHTML="*Invalid Mobile Number!";
         document.getElementById("phone").focus();
        return false;
    }
    else if(pass!==cpass)
    {
       
        document.getElementById("error_pass").innerHTML="*Password and Confirm Password Does Not Match!";
        document.getElementById("cpass").focus();
        return false;
    }
    else if(pass.length<6)
    {
        
        document.getElementById("error_pass").innerHTML="*Password Must be 6 Character Length!";
        document.getElementById("pass").focus();
        return false;
    }
    else 
    {
        return true;
    }
}


