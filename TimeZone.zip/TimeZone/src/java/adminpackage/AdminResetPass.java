/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adminpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author HP
 */
public class AdminResetPass extends HttpServlet {

    Connection con;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AdminResetPass</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet AdminResetPass at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession s1 = request.getSession(false);
        String email = (String) s1.getAttribute("email");
        PrintWriter out = response.getWriter();
        String pass = request.getParameter("pass");
        String cpass = request.getParameter("cpass");
        HttpSession s = request.getSession();

        try {
            if (!pass.equals(cpass)) {
                s.setAttribute("fail", "Password and Confirm Password Does Not Match");
                response.sendRedirect("Admin/resetpass.jsp");
            } else if (pass.length() < 6 || cpass.length() < 6) {
                s.setAttribute("fail", "Password Should be More than 6 Character!");
                response.sendRedirect("Admin/resetpass.jsp");
            } else {
                try {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/timezone?useTimeZone=true&serverTimezone=UTC&autoReconnect=true&useSSL=false", "root", "root");
                    PreparedStatement stm = con.prepareStatement("update admininfo set password=? where email=?");
                    stm.setString(1, pass);
                    stm.setString(2, email);
                    int rs = stm.executeUpdate();
                    if (rs > 0) {
                        s.setAttribute("success", "Password Changed Successfully!");
                        response.sendRedirect("Admin/adminlogin.jsp");
                        s1.removeAttribute("email");
                    }
                } catch (Exception ex) {
                    s.setAttribute("fail", ex);
                    response.sendRedirect("Admin/resetpass.jsp");
                }

            }
        } catch (Exception ex) {
            s.setAttribute("fail", ex);
            response.sendRedirect("Admin/resetpass.jsp");
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                out.println(ex);
            }
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
