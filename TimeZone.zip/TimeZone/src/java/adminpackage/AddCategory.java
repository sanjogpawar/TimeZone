/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adminpackage;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import javax.servlet.http.HttpSession;


public class AddCategory extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AddCategory</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet AddCategory at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       HttpSession s=request.getSession();
       String cname=request.getParameter("category");
       HttpSession s1=request.getSession(false);
      
       
       try
       {
           Class.forName("com.mysql.cj.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/timezone?useTimeZone=true&serverTimezone=UTC&autoReconnect=true&useSSL=false","root","root");
           PreparedStatement p=con.prepareStatement("select * from category where category=?");
           p.setString(1, cname);
           ResultSet rs=p.executeQuery();
           if(rs.next())
           {
               s.setAttribute("fail","Category Already Exist!");
               response.sendRedirect("Admin/category.jsp");
           }
           else
           {
               try
               {
                   PreparedStatement ps=con.prepareStatement("insert into category(category,status) values(?,?)");
                   ps.setString(1, cname);
                   ps.setInt(2, 1);
                   int row=ps.executeUpdate();
                   if(row>0)
                   {
                       s.setAttribute("Success","Category Added Successfully!");
                       response.sendRedirect("Admin/category.jsp");
                   }
               }
               catch(Exception ex)
               {
                   s.setAttribute("fail",ex);
                   response.sendRedirect("Admin/category.jsp");
               }
               
           }
       }
       catch(Exception ex)
       {
           s.setAttribute("fail",ex);
           response.sendRedirect("Admin/category.jsp");
       }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
