/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adminpackage;

import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class EditProfile extends HttpServlet {
Connection con;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession(false);
        String id = (String) session.getAttribute("admin");
        String aname = request.getParameter("aname");
        String email = request.getParameter("email");
        String pass = request.getParameter("pass");
        String cpass = request.getParameter("cpass");
        HttpSession s = request.getSession();
        if (aname.isEmpty() || email.isEmpty() || pass.isEmpty() || cpass.isEmpty()) {
            s.setAttribute("fail", "Please Fill Required Detail!");
            response.sendRedirect("Admin/profile.jsp");
        } else if (!aname.matches("^[a-zA-z\\s]+$")) {
            s.setAttribute("fail", "Invalid Name!");
            response.sendRedirect("Admin/profile.jsp");
        } else if (!email.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
            s.setAttribute("fail", "Invalid Email!");
            response.sendRedirect("Admin/profile.jsp");

        } else if (pass.length() < 6) {
            s.setAttribute("fail", "Password Must be More than 6 Character!");
            response.sendRedirect("Admin/profile.jsp");
        } else if (!pass.equals(cpass)) {
            s.setAttribute("fail", "Password and Confirm Password Does Not Match!");
            response.sendRedirect("Admin/profile.jsp");
        } else {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/timezone?useTimeZone=true&serverTimezone=UTC&autoReconnect=true&useSSL=false", "root", "root");
                PreparedStatement ps = con.prepareStatement("update admininfo set aname=?,email=?,password=? where id=?");
                ps.setString(1, aname);
                ps.setString(2, email);
                ps.setString(3, pass);
                ps.setString(4, id);
                int row = ps.executeUpdate();
                if (row > 0) {
                    s.setAttribute("success", "Account Updated Successfully!");
                    s.setAttribute("admin", id);
                    response.sendRedirect("Admin/profile.jsp");
                    
                
                } else {
                    s.setAttribute("fail", "Something Went Wrong!");
                    response.sendRedirect("Admin/profile.jsp");
                }

            } catch (SQLException e) {
                out.println(e);
            } catch (ClassNotFoundException ex) {
               out.println(ex);
            }
            finally
            {
                try {
                    con.close();
                } catch (SQLException ex) {
                   out.println(ex);
                }
            }

        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
