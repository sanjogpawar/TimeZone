/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adminpackage;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import javax.servlet.http.HttpSession;


public class AdminLogin extends HttpServlet {

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         response.setContentType("text/html;charset=UTF-8");
         PrintWriter out=response.getWriter();
         String email=request.getParameter("email");
         String pass=request.getParameter("password");
         HttpSession s=request.getSession();
        
         try
         {
             Class.forName("com.mysql.cj.jdbc.Driver");
             Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/timezone?useTimeZone=true&serverTimezone=UTC&autoReconnect=true&useSSL=false","root","root");
             PreparedStatement stm=con.prepareStatement("select * from admininfo where email=? and password=?");
             stm.setString(1, email);
             stm.setString(2, pass);
             ResultSet rs=stm.executeQuery();
             
             if(rs.next())
             {
                 s.setAttribute("admin",rs.getString("id"));
                 response.sendRedirect("Admin/dashboard.jsp");
             }
             else
             {
                 s.setAttribute("fail", "Incorrect Email or Password!");
                 response.sendRedirect("Admin/adminlogin.jsp");
             }
             con.close();
         }
         catch(IOException | ClassNotFoundException | SQLException e)
         {
              s.setAttribute("fail", e);
              response.sendRedirect("Admin/adminlogin.jsp");
         }
        
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
