/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adminpackage;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Part;



@MultipartConfig(maxFileSize = 16177215)//size upto 16mb
public class AddProduct extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AddProduct</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet AddProduct at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out=response.getWriter();
        HttpSession s=request.getSession();
        String author=request.getParameter("author");
        String wname=request.getParameter("bname");
        String price=request.getParameter("price");
        String qty=request.getParameter("qty");
        String desc=request.getParameter("desc");
        String category=request.getParameter("category"); 
        Part part=request.getPart("image");//it is used to fetch the file path
        String fname=part.getSubmittedFileName();//to get the filename
        out.println(fname);
        if(author.isEmpty() || wname.isEmpty() || price.isEmpty() || qty.isEmpty() || desc.isEmpty() || category.isEmpty()|| fname.isEmpty())
        {
            s.setAttribute("fail", "Please Kindly Fill All Information!");
            response.sendRedirect("Admin/addproduct.jsp");
        }
        else if(category.equals("-1"))
        {
            s.setAttribute("fail", "Please Select Category!");
            response.sendRedirect("Admin/addproduct.jsp");
        }
        else if(!(fname.endsWith(".jpg") || fname.endsWith(".jpeg") || fname.endsWith(".png") || fname.endsWith(".gif")))
        {
            s.setAttribute("fail", "Please Upload Valid Image!");
            response.sendRedirect("Admin/addproduct.jsp");
        }
        else if(!author.matches("^[A-z\\s\\.]+$"))
        {
            s.setAttribute("fail", "Invalid Author Name!");
            response.sendRedirect("Admin/addproduct.jsp");
        }
        else if(!wname.matches("^[A-z\\s@-_&!']+$"))
        {
            s.setAttribute("fail", "Invalid Watch Name!");
            response.sendRedirect("Admin/addproduct.jsp");
        }
        else if(!price.matches("^\\d+(?:[.]\\d+)*$"))
        {
            s.setAttribute("fail", "Invalid Price!");
            response.sendRedirect("Admin/addproduct.jsp");
        }
        else if(!qty.matches("^[0-9]+$"))
        {
            s.setAttribute("fail", "Invalid Quantity!");
            response.sendRedirect("Admin/addproduct.jsp");
        }
        else
        {
            try 
            {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/timezone?useTimeZone=true&serverTimezone=UTC&autoReconnect=true&useSSL=false","root","root");  
                try
                {
                   PreparedStatement ps=con.prepareStatement("insert into watchdetails(wname,details,category,qty,price,wimage,description,status) values(?,?,?,?,?,?,?,?)");
                    ps.setString(1, wname);
                    ps.setString(2,author);
                    ps.setString(3, category);
                    ps.setString(4,qty);
                    ps.setString(5,price);
                    ps.setString(5, price);
                    ps.setString(6, fname);
                    ps.setString(7, desc);
                    ps.setInt(8,1);
                    int row=ps.executeUpdate();
                    FileOutputStream fout=new FileOutputStream("C:\\Users\\sanjo\\Downloads\\ProjectOfAdvance\\ProjectOfAdvance\\TimeZone\\web\\Admin\\images\\"+fname);
                    InputStream filecontent=part.getInputStream();
                    int read = 0;
                    final byte[] bytes = new byte[1024];
                    while ((read = filecontent.read(bytes)) != -1) {
                        fout.write(bytes, 0, read);
                    }
                    if(row>0)
                    {
                        
                        s.setAttribute("success", "Watch Added Successfully");
                        response.sendRedirect("Admin/viewproduct.jsp");
                        con.close();
                    }
                }
                catch(IOException | SQLException ex)
                {
                    s.setAttribute("fail", ex);
                    response.sendRedirect("Admin/addproduct.jsp");
                }
            } 
            catch (IOException | ClassNotFoundException | SQLException ex) 
            {
                s.setAttribute("fail", ex);
                response.sendRedirect("Admin/addproduct.jsp");
            }
            
        }
        
        
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
