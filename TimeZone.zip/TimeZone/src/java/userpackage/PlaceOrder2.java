package userpackage;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpSession;

/**
 *
 * @author HP
 */
public class PlaceOrder2 extends HttpServlet {

    Connection con;
    PreparedStatement ps;

    protected void sendmail(HttpServletRequest request, HttpServletResponse response, java.util.Date current) throws IOException, ClassNotFoundException, ParseException {
        PrintWriter out = response.getWriter();
        HttpSession s = request.getSession(false);
        String paymethod = request.getParameter("paymethod");
        String userid = (String) s.getAttribute("user");
        String to = request.getParameter("email");
        double total = 0;
        int orderid = 0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/timezone?useTimeZone=true&serverTimezone=UTC&autoReconnect=true&useSSL=false", "root", "root");
            PreparedStatement stm = con.prepareStatement("select * from userinfo where id=?");
            stm.setString(1, userid);
            ResultSet rs = stm.executeQuery();
            if (rs.next()) {
                PreparedStatement stm1 = con.prepareStatement("select orderdetails.*,orders.total,orders.added,watchdetails.wname from orderdetails inner join orders inner join watchdetails on orderdetails.orderid=orders.id and orderdetails.wid=watchdetails.wid where orders.uid=? and orders.added=? ");
                stm1.setString(1, userid);
                java.sql.Date sqlDate = new java.sql.Date(current.getTime());
                stm1.setDate(2, sqlDate);
                ResultSet rs1 = stm1.executeQuery();
                Properties props = new Properties();
                props.put("mail.smtp.host", "smtp.gmail.com");                                       //group by watchdetails.wname
                props.put("mail.smtp.starttls.enable", "true");
                props.put("mail.smtp.socketFactory.port", "587");
                props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
                props.put("mail.smtp.auth", "true");
                props.put("mail.smtp.port", "465");
                Session session = Session.getInstance(props, new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication("sanjogpawar31@gmail.com", "amdlulykixtbogbi");// Put your email                                                                                                                                                               // password here
                    }
                });
                try {
                    MimeMessage message = new MimeMessage(session);
                    message.setFrom(new InternetAddress(rs.getString("email")));// change accordingly
                    message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
                    message.setSubject("Your Findwatches.in Order for 1 items has been placed");
                    String msg = "<h2>Hello, " + rs.getString("fname") + "<br>"
                            + "<h3 style='color:orange'>Your Order Summary:</h3><br>"
                            + "<table style='border-collapse:collapse;width:50%;text-align:center' border='1'>"
                            + "<tr >"
                            + "<th style='padding:10px'>Watch Id</th>"
                            + "<th style='padding:10px'>Watch Name</th>"
                            + "<th style='padding:10px'>Price</th>"
                            + "</tr>";
                    while (rs1.next()) {
                        total = rs1.getDouble("total");
                        orderid = rs1.getInt("orderid");
                        msg = msg + "<tr style='font-weight:5px;padding:10px'>"
                                + "<td style='padding:10px'>" + rs1.getString("wid") + "</td>"
                                + "<td style='padding:10px'>" + rs1.getString("wname") + "</td>"
                                + "<td style='padding:10px'>&#8377;" + rs1.getString("price") + "</td>"
                                + "</tr>";

                    }
                    msg = msg + "<tr ><th colspan='2' style='color:orange' align='left'>&nbsp;&nbsp;&nbsp;&nbsp;Order ID</th>"
                            + "<th style='color:orange;padding:10px' >#" + orderid + "</th>"
                            + "</tr>"
                            + "<tr ><th colspan='2' style='color:orange' align='left'>&nbsp;&nbsp;&nbsp;&nbsp;Total</th>"
                            + "<th style='color:orange;padding:10px'> &#8377;" + total + "</th>"
                            + "</tr>"
                            + "</table>";
                    message.setContent(msg, "text/html");
                    // send message
                    Transport.send(message);
                    if (paymethod.equalsIgnoreCase("cod")) {
                        response.sendRedirect("User/vieworders.jsp");
                    } else if (paymethod.equalsIgnoreCase("epay")) {
                        response.sendRedirect("User/payment.jsp");
                    }

                } catch (IOException | SQLException | MessagingException ex) {
                    out.println(ex);
                }
            }
        } catch (SQLException ex) {
            out.println(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                out.println(ex);
            }
        }

    }

    protected void orders(HttpServletRequest request, HttpServletResponse response, int recent_id, java.util.Date current) throws IOException, ClassNotFoundException, ParseException {
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession(false);
        String wid = (String) session.getAttribute("wid");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/timezone?useTimeZone=true&serverTimezone=UTC&autoReconnect=true&useSSL=false", "root", "root");
            PreparedStatement ps1 = con.prepareStatement("select * from watchdetails where wid=?");
            ps1.setString(1, wid);
            ResultSet rs = ps1.executeQuery();
            //for using batch always write the query outside the loop otherwise it will consider new query in every iteration
            if (rs.next()) {
                ps = con.prepareStatement("insert into orderdetails(orderid,wid,price) values(?,?,?);");
                ps.setInt(1, recent_id);
                ps.setString(2, rs.getString("wid"));
                ps.setString(3, rs.getString("price"));
                int row = ps.executeUpdate();
                if (row > 0) {
                    int qty = rs.getInt("qty") - 1;
                    PreparedStatement ps4 = con.prepareStatement("update watchdetails set qty=? where wid=?");
                    ps4.setInt(1, qty);
                    ps4.setInt(2, rs.getInt("wid"));
                    ps4.executeUpdate();
                    sendmail(request, response, current);
                }
            }

        } catch (SQLException ex) {
            out.println(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                out.println(ex);
            }
        }
    }

    protected void orderdetails(HttpServletRequest request, HttpServletResponse response) throws IOException, ClassNotFoundException, ParseException {
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession(false);
        HttpSession s1 = request.getSession();
        String total = String.valueOf(session.getAttribute("total"));
        String paymethod = request.getParameter("paymethod");
        String userid = (String) session.getAttribute("user");
        String paystatus = "pending";
        String orderstatus = "pending";
        java.util.Date d = new java.util.Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String date = formatter.format(d);
        java.util.Date myDate = formatter.parse(date);
        java.sql.Date sqlDate = new java.sql.Date(myDate.getTime());

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/timezone?useTimeZone=true&serverTimezone=UTC&autoReconnect=true&useSSL=false", "root", "root");
            if (paymethod.equalsIgnoreCase("cod")) {
                paystatus = "success";
            }
            PreparedStatement ps2 = con.prepareStatement("Insert into orders(uid,paymethod,paystatus,orderstatus,total,added) values(?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
            ps2.setString(1, userid);
            ps2.setString(2, paymethod);
            ps2.setString(3, paystatus);
            ps2.setString(4, orderstatus);
            ps2.setString(5, total);
            ps2.setDate(6, sqlDate);
            int row = ps2.executeUpdate();
            ResultSet rs = ps2.getGeneratedKeys();
            if (rs.next()) {
                int recent_id = rs.getInt(1);
                if (row > 0) {
                    orders(request, response, recent_id, sqlDate);
                }
            }

        } catch (SQLException ex) {
            out.println(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                out.println(ex);
            }
        }
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession(false);
        String userid = (String) session.getAttribute("user");

        String email = request.getParameter("email");
        String add = request.getParameter("add");
        String landmark = request.getParameter("landmark");
        String zip = request.getParameter("zip");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/timezone?useTimeZone=true&serverTimezone=UTC&autoReconnect=true&useSSL=false", "root", "root");
            PreparedStatement ps1 = con.prepareStatement("update userinfo set address=?,city=?,state=?,zipcode=?,landmark=?,email=? where id=?");
            ps1.setString(1, add);
            ps1.setString(2, city);
            ps1.setString(3, state);
            ps1.setString(4, zip);
            ps1.setString(5, landmark);
            ps1.setString(6, email);
            ps1.setString(7, userid);
            int row = ps1.executeUpdate();

            if (row > 0) {
                orderdetails(request, response);
            }

        } catch (Exception ex) {
            out.println(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                out.println(ex);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
