/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userpackage;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import javax.servlet.http.HttpSession;

/**
 *
 * @author HP
 */
public class EditUserProfile extends HttpServlet {
Connection con;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();
        HttpSession s1=request.getSession(false);
        String id=(String) s1.getAttribute("user");
        String fname=request.getParameter("fname");
        String lname=request.getParameter("lname");
        String email=request.getParameter("email");
        String pass=request.getParameter("pass");
        String phone=request.getParameter("phone");
        String cpass=request.getParameter("cpass");
        HttpSession s=request.getSession();
        if(fname.isEmpty() || lname.isEmpty() || email.isEmpty() || pass.isEmpty() || cpass.isEmpty() || phone.isEmpty())
        {
             s.setAttribute("fail","Please Fill Required Detail!");
             response.sendRedirect("User/userprofile.jsp");
        }
        else if(!fname.matches("^[a-zA-z]+$"))
        {
            s.setAttribute("fail","Invalid First Name!");
            response.sendRedirect("User/userprofile.jsp");
        }
        else if(!lname.matches("^[a-zA-z]+$"))
        {
            s.setAttribute("fail","Invalid Last Name!");
            response.sendRedirect("User/userprofile.jsp");
        }
        else if(!email.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$"))
        {
            s.setAttribute("fail","Invalid Email!");
            response.sendRedirect("User/userprofile.jsp");

        }
        else if(!phone.matches("^[0-9]{10}$"))
        {
            s.setAttribute("fail","Invalid Phone Number!");
            response.sendRedirect("User/userprofile.jsp");

        }
        else if(pass.length()<6)
        {
            s.setAttribute("fail","Password Must be More than 6 Character!");
            response.sendRedirect("User/userprofile.jsp");
        }
        else if(!pass.equals(cpass))
        {
            s.setAttribute("fail","Password and Confirm Password Does Not Match!");
            response.sendRedirect("User/userprofile.jsp");
        }
        else
        {
            try
            {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/timezone?useTimeZone=true&serverTimezone=UTC&autoReconnect=true&useSSL=false","root","root");
                PreparedStatement ps=con.prepareStatement("update userinfo set fname=?,lname=?,phone=?,email=?,password=? where id=?");
                ps.setString(1, fname);
                ps.setString(2, lname);
                ps.setString(3, phone);
                ps.setString(4, email);
                ps.setString(5, pass);
                ps.setString(6,id);
                int row=ps.executeUpdate();
                if(row>0)
                {
                    s.setAttribute("success","Account Updated Successfully!");
                    response.sendRedirect("User/userprofile.jsp");
                    s.setAttribute("user", id);
                    con.close();
                }
                else
                {
                   s.setAttribute("fail","Something Went Wrong!");
                   response.sendRedirect("User/userprofile.jsp");
                }

            }
            catch(Exception e)
            {
                out.println(e);
            }

        }
        
          
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
