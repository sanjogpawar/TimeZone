/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userpackage;

import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author HP
 */
public class AddtoCart extends HttpServlet {

    Connection con;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession(false);
        HttpSession s = request.getSession();
        String user = (String) session.getAttribute("user");
        String wid = "";
        if (user == null) {
            response.sendRedirect("User/userlogin.jsp");
        } else {
            if (request.getParameter("id") != null) {
                wid = request.getParameter("id");
                try {

                    Class.forName("com.mysql.cj.jdbc.Driver");
                    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/timezone?useTimeZone=true&serverTimezone=UTC&autoReconnect=true&useSSL=false", "root", "root");
                    PreparedStatement ps1 = con.prepareStatement("select * from usercart where wid=? and userid=?");
                    ps1.setString(1, wid);
                    ps1.setString(2, user);
                    ResultSet rs = ps1.executeQuery();
                    if (rs.next()) {
                         s.setAttribute("fail", "Watch Already Exist in Cart!");
                         response.sendRedirect("User/viewcart.jsp");
                    } else {
                        PreparedStatement ps = con.prepareStatement("insert into usercart(userid,wid) values(?,?)");
                        ps.setString(1, user);
                        ps.setString(2, wid);
                        int row = ps.executeUpdate();
                        if (row > 0) {
                            s.setAttribute("success", "Watch Added Successfully!");
                            s.setAttribute("added", "success");
                            response.sendRedirect("User/viewcart.jsp");
                        } else {
                            s.setAttribute("fail", "Something Went Wrong!");
                            response.sendRedirect("User/viewcart.jsp");
                        }
                    }
                } catch (IOException | ClassNotFoundException | SQLException ex) {

                }
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
