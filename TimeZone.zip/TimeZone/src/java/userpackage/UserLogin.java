/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author HP
 */
public class UserLogin extends HttpServlet {
Connection con;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
         PrintWriter out=response.getWriter();
         String email=request.getParameter("email");
         String pass=request.getParameter("pass");
         HttpSession s=request.getSession();
        
         try
         {
             Class.forName("com.mysql.cj.jdbc.Driver");
             con=DriverManager.getConnection("jdbc:mysql://localhost:3306/timezone?useTimeZone=true&serverTimezone=UTC&autoReconnect=true&useSSL=false","root","root");
             PreparedStatement stm=con.prepareStatement("select * from userinfo where email=? and password=?");
             stm.setString(1, email);
             stm.setString(2, pass);
             ResultSet rs=stm.executeQuery();
             if(rs.next())
             {
                 s.setAttribute("user",rs.getString("id"));
                 response.sendRedirect("User/Home2.jsp");
             }
             else
             {
                 s.setAttribute("fail", "Incorrect Email or Password!");
                 response.sendRedirect("User/userlogin.jsp");
             }
             con.close();
         }
         catch(IOException | ClassNotFoundException | SQLException e)
         {
              s.setAttribute("fail", e);
              response.sendRedirect("User/userlogin.jsp");
         }
         finally    
         {
             try
             {
                 con.close();
             }
             catch(SQLException ex)
             {
                s.setAttribute("fail", ex);
                response.sendRedirect("User/userlogin.jsp");
             }
         }
     
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
